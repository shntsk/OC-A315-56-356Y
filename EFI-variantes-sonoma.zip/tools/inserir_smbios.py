#!/usr/bin/env python3
"""Copia o bloco PlatformInfo de uma config.plist SUA (a que você realmente usa)
para todas as variantes, sem imprimir nenhum identificador.
Uso: python3 inserir_smbios.py /caminho/da/SUA/config.plist /caminho/das/variantes
"""
import re, sys, pathlib
BLOCK = re.compile(r'\t<key>PlatformInfo</key>\n\t<dict>\n.*?\n\t</dict>\n', re.S)

def main(src, root):
    m = BLOCK.search(pathlib.Path(src).read_text(encoding='utf-8'))
    if not m:
        sys.exit('PlatformInfo não encontrado na config de origem (esperado formato padrão do OpenCore).')
    n = 0
    for cfg in sorted(pathlib.Path(root).glob('*/EFI/OC/config.plist')):
        t = cfg.read_text(encoding='utf-8')
        if len(BLOCK.findall(t)) != 1:
            sys.exit(f'{cfg}: bloco PlatformInfo não encontrado/ambíguo')
        cfg.write_text(BLOCK.sub(lambda _: m.group(0), t, count=1), encoding='utf-8')
        n += 1
    print(f'PlatformInfo copiado para {n} config.plist (valores não exibidos).')

if __name__ == '__main__':
    if len(sys.argv) != 3: sys.exit(__doc__)
    main(*sys.argv[1:])
