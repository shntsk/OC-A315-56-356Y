# Acer Aspire 3 A315-56-356Y — Sonoma sem vídeo (OpenCore)

Resultado desta auditoria (feita só com arquivos; **nenhum boot físico foi feito**).

## 1. Resumo honesto

- **Não consegui provar a causa do "sem vídeo" só com os arquivos.** O ZIP não tem logs, e não tenho como iniciar o macOS aqui. Qualquer "correção definitiva" seria chute. Por isso entrego um **controle de diagnóstico** e **4 variantes**, cada uma mudando **uma** variável em relação ao controle.
- **O ZIP anexado é idêntico, byte a byte, ao repositório público** `juniorcaesar/OC-A315-56-327T` (branch main, conferido com `diff -r`). Não há nenhuma customização sua nele. Se você usa uma EFI diferente da pública, anexe-a: a auditoria abaixo vale para o ZIP recebido.
- O repositório de referência declara suporte a Big Sur, Monterey e Ventura 13.1. **Sonoma nunca foi validado por ele.**
- Nada aqui confirma aceleração gráfica nem Metal. Isso só se confirma no notebook (seção 7).

## 2. O que foi verificado por ferramenta

| Item | Resultado |
|---|---|
| `OpenCore.efi`, `BOOTx64.efi`, `OpenRuntime`, `OpenPartitionDxe`, `ResetNvramEntry`, `OpenShell` | Hash idêntico ao **OpenCore 0.9.6 RELEASE** oficial. O README diz 1.0.1 (badge), mas o binário **não** é 1.0.1. |
| Build do OpenCore | **RELEASE**: não gera log em arquivo. Por isso a EFI original não permite diagnosticar. |
| `Lilu.kext` 1.6.7 / `WhateverGreen.kext` 1.6.6 | Binários idênticos aos oficiais. Ambos são de **07/08/2023**, anteriores ao Sonoma 14.0 final. |
| Ordem dos kexts | Lilu antes de WhateverGreen e AppleALC; todos os caminhos de kext/SSDT/driver do `config.plist` existem. |
| `ocvalidate` 0.9.6 (versão correta) | 1 erro: `PlatformInfo->Generic->SystemUUID` inválido (veja item abaixo). Nada mais. |
| XML (`xmllint`) e plist (`plistlib`) | OK em todos os arquivos. |
| SMBIOS | O `SystemUUID` do ZIP tem formato inválido e não é seu: é o **placeholder do repositório público**. Não alterei nem exibi nenhum valor. |

Notas de versão do WEG 1.6.7 a 1.7.1 e do Lilu 1.6.8 a 1.7.2 não mencionam nenhuma correção específica de Ice Lake. Então atualizar kexts é uma hipótese plausível, não uma certeza.

## 3. Gráficos Ice Lake: ZIP vs. manual do WhateverGreen

| Propriedade (IGPU `PciRoot(0x0)/Pci(0x2,0x0)`) | Valor no ZIP | Avaliação |
|---|---|---|
| Caminho PCI | `Pci(0x2,0x0)` | Padrão Intel; coerente. |
| `device-id` | `5C8A0000` (0x8A5C) | 0x8A5C está na lista de IDs **nativos** do manual. Só é necessário se o ID real **não** for nativo. **Confirme o ID real** (seção 6). |
| `AAPL,ig-platform-id` | `02005C8A` (0x8A5C0002) | Existe na lista de framebuffers ICL do manual (móvel, 3 conectores). O padrão do manual é 0x8A520000. |
| `framebuffer-patch-enable`, `stolenmem` 19 MB, `fbmem` 9 MB | presentes | Idêntico ao exemplo do manual para DVMT de 32 MB. |
| `enable-dvmt-calc-fix`, `enable-cdclk-frequency-fix`, `enable-dbuf-early-optimizer`, `enable-backlight-registers-fix` | presentes | Todos documentados para ICL. O manual diz que ICL **não** é afetada pela quebra do BLR no macOS 13.4+. |
| `enable-backlight-smoother` | presente | Documentado (IVB+). |
| `igfxfw` = 2 | presente | Documentado como "força carregar o firmware GuC da Apple". Não é mencionado na seção ICL. |
| `AAPL,GfxYTile` | presente | O manual só o cita para Skylake/Kaby Lake. Para ICL não achei documentação. |
| `boot-args` | `-noDC9` | Não aparece no manual nem no README do WEG. Não consegui verificar a origem. Mantido. |
| Propriedades duplicadas ou patches conflitantes | **nenhum** encontrado | |
| `SSDT-PNLF` | usa `\_SB.PCI0.GFX0` | Caminho padrão. **Não verifiquei** contra o DSDT do seu notebook (não está no ZIP). |

Conclusão: a configuração gráfica é **consistente com o manual**; não achei erro óbvio nela. Isso reforça que a causa está em algo dependente de Sonoma (versão de Lilu/WEG, OpenCore 0.9.6) ou em iluminação, e não em um valor "errado" de framebuffer.

Sobre "iluminação x aceleração": se a tela só parece preta, mas o sistema subiu, o problema é backlight, não GPU. Como separar: seção 7.

## 4. As variantes (cada uma muda UMA coisa em relação ao controle 01)

| Pasta | O que muda | Por que testar |
|---|---|---|
| `01-controle-diag` | Só diagnóstico: OpenCore 0.9.6 **DEBUG** (mesma versão), Lilu/WEG **DEBUG** (mesmas versões), `-v keepsyms=1 -liludbgall`, log em arquivo | Gera evidência. Se o vídeo funcionar aqui, o problema era o boot gráfico/temporização, não a configuração. |
| `02-kexts-lilu172-weg171` | Lilu 1.7.2 + WhateverGreen 1.7.1 (DEBUG) | Os atuais são de antes do Sonoma final; as correções de ICL são patches binários no driver da Apple e podem deixar de casar. |
| `03-sem-backlight-smoother` | Remove `enable-backlight-smoother` | Isola um problema de brilho (tela escura com sistema vivo). |
| `04-sem-igfxfw` | Remove `igfxfw` | Isola o carregamento forçado do GuC da Apple. |
| `05-framebuffer-8A520000` | `AAPL,ig-platform-id` 0x8A5C0002 → 0x8A520000 | É o framebuffer padrão/recomendado do manual. |

Variantes **não** feitas, de propósito: atualizar o OpenCore (mudaria o esquema do config e é outra variável), atualizar o VoodooI2C (quebra os botões do touchpad, conforme o próprio README), mexer em HDMI (o README diz que não funciona em Ice Lake; não investigado).

## 5. Valores alterados no `config.plist`

Em **todas** as variantes 01 a 05 (diagnóstico):

| Chave | Antes | Depois |
|---|---|---|
| `Misc→Debug→AppleDebug` | false | true |
| `Misc→Debug→DisplayLevel` | 2147483650 | 2147483714 |
| `Misc→Debug→SysReport` | false | true |
| `Misc→Debug→Target` | 3 | 67 (tela + arquivo) |
| `NVRAM→…7C436110…→boot-args` | `-noDC9` | `-noDC9 -v keepsyms=1 -liludbgall` |

Só em uma variante cada:

- 03: removida `DeviceProperties→…Pci(0x2,0x0)→enable-backlight-smoother`.
- 04: removida `…→igfxfw`.
- 05: `…→AAPL,ig-platform-id` de `02005C8A` para `0000528A`.

Arquivos trocados no 01 (e herdados pelos demais): `BOOT/BOOTx64.efi`, `OC/OpenCore.efi`, `OC/Drivers/{OpenRuntime,OpenPartitionDxe,ResetNvramEntry}.efi`, `OC/Tools/OpenShell.efi` (todos 0.9.6 DEBUG) e `Lilu.kext`/`WhateverGreen.kext` (DEBUG). No 02, os dois kexts são 1.7.2/1.7.1. `.DS_Store` removidos. Nada mais foi tocado (SMBIOS, ACPI, demais kexts, quirks).

## 6. Antes de testar

1. **Reinsira o seu SMBIOS.** As configs vêm com o placeholder do repositório. Opção rápida (não imprime nada):
   `python3 tools/inserir_smbios.py /caminho/da/SUA/config.plist /caminho/desta/pasta`
   Com um UUID válido, as 6 configs passaram no `ocvalidate` com "No issues found" (testei com um UUID sintético).
2. **Descubra o device-id real da GPU** (você tem Arch Linux no mesmo notebook): `lspci -nn -s 00:02.0`. Se o ID real já for um dos nativos (8A51, 8A5C, 8A5D, 8A52, 8A53, 8A5A, 8A5B), o `device-id` injetado não é necessário.

## 7. Procedimento seguro de teste

1. Faça backup da EFI atual do disco (copie a pasta `EFI` da partição EFI para um lugar seguro). Ela é o seu "voltar atrás".
2. **Teste por pendrive**, sem mexer na EFI do SSD: formate um pendrive em FAT32/GPT, copie a pasta `EFI` da variante para a raiz dele e escolha o pendrive no menu de boot da BIOS. Teste uma variante por vez, na ordem 01, 02, 03, 04, 05.
3. No OpenCore, escolha **Reset NVRAM** antes de trocar de variante (o menu tem `ResetNvramEntry`).
4. Para voltar: tire o pendrive; o SSD continua com a EFI antiga.

## 8. Coletar logs se continuar sem vídeo

- **Log do OpenCore:** com o pendrive gravável, o arquivo `opencore-AAAA-MM-DD-hhmmss.txt` aparece em `EFI/OC/` (e a pasta `SysReport`). Leia no Ventura/Linux e me envie.
- **Foto/vídeo da tela verbose** (`-v`) no ponto em que apaga.
- **Se o macOS subir mas a tela estiver escura:** acesse por SSH pela Ethernet (RTL8111 funciona; o Wi-Fi RTL8821CE não) e rode:
  - `sudo dmesg | grep -iE "igfx|IGFB|lilu|WhateverGreen|ICL"`
  - `system_profiler SPDisplaysDataType` (chipset, VRAM e a linha "Metal Support")
  - `ioreg -l | grep -iE "AppleIntelICLLP|dvmt"`
  - `kmutil showloaded --list-only | grep -i ICL`
- **Como saber que a aceleração funciona** (e não só que há imagem): `system_profiler` mostra a GPU Intel com VRAM e uma linha de Metal; o driver `AppleIntelICLLP…` aparece carregado; a interface tem transparência/animações normais e o osu! para de apresentar os glitches do Ventura. Só considere resolvido se **todos** baterem.

## 9. O que NÃO foi verificado

- Nenhum boot real, nem do Sonoma nem de qualquer variante.
- Qual versão exata do Sonoma você instalou (14.0 a 14.8 podem se comportar diferente).
- O device-id real da sua GPU e o DVMT real da BIOS.
- O DSDT do seu notebook (nomes `GFX0`/`PR00` usados pelas SSDTs).
- Se o seu SMBIOS real difere do placeholder (ele não está no ZIP).
